#include<stdio.h>
int main(void) {
	int sl = 0, total = 0, avsl = 0;
	for (int i = 0; i < 7; i++)
	{
		printf("the time you sleep:");
		scanf_s("%d", &sl);
		total = total + sl;
	}
	avsl = total / 6;
	printf("avx=%d\ntotal=%d\n", avsl, sl);
	if (avsl<6)
	{
		printf("˯�߲���");
	}
	else if(avsl>8){
		printf("˯�߳���");
	}
	else {
		printf("����");
	}
	return 0;
}