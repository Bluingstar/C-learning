#include<stdio.h>
int main(void) {
	int a = 0, b = 0, c = 0, d = 0, max = 0, min = 0;
	printf("Enter four integets\n");
	scanf_s("%d %d %d %d", &a, &b, &c, &d);
	int num[4] = { a,b,c,d };
	max = a;
	min = a;
	for (int i = 0; i < 4; i++)
	{
		if (max <= num[i]) {
			max = num[i];
		}
		if (min >= num[i]) {
			min = num[i];
		}

	}
	printf("Largest:%d\nSmallest:%d\n", max, min);
	return 0;
}