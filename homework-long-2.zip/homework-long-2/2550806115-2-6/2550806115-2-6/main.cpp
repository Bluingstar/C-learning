#include<stdio.h>
int main(void) {
	int n = 0;
	printf("Type in a number\n");
	scanf_s("%d", &n);
	for (int i = 2; i*i < n; i=i+2)
	{
		printf("%d\n", i * i);
	}
	return 0;
}