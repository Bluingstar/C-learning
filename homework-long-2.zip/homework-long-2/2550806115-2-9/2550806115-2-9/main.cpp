#include<stdio.h>
int main(void) {
	double dx = 0, total = 0, avx = 0;
	for (int i = 0; i < 6; i++)
	{
		printf("the dx you run:");
		scanf_s("%lf", &dx);
		total = total + dx;
	}
	avx = total / 6;
	printf("avx=%lf\ntotal=%lf\n", avx, dx);
	if (total>30)
	{
		printf("��ֵúܺ�");
	}
	return 0;
}