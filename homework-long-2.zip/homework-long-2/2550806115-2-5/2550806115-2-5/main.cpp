#include<stdio.h>
int main(void) {
	double max = 0;
	double input = 1;
	do
	{
		printf("Enter a number:\n");
		scanf_s("%lf", &input);
		if (max<input)
		{
			max = input;
		}
	} while (input>0);
	printf("The largest number entered was %lf", max);
	return 0;
}