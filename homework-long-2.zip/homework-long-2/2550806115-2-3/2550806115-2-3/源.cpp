#include<stdio.h>
int main(void) {
	int takeoff[8] = { 480,583,679,767,840,945,1140,1305 };
	int time = 0, h = 0, m = 0;
	int dt2 = 0, dt2Min = 1440;
	int choose = 0;
	printf("Enter a 24-hour time(h:m):\n");
	scanf_s("%d:%d", &h, &m);
	time = h * 60 + m;
	for (int i = 0; i <8 ; i++)
	{
		dt2 = time - takeoff[i];
		dt2 = dt2 * dt2;
		if (dt2 < dt2Min) {
			dt2Min = dt2;
			choose = takeoff[i];
		}
	}
	switch (choose) {
		case 480:
			printf("Closest departure time is 8:00am,arriving at 10:16am");
			break;
		case 583:
			printf("Closest departure time is 9:43am,arriving at 11:52am");
			break;
		case 679:
			printf("Closest departure time is 11:19am,arriving at 1:31pm");
			break;
		case 767:
			printf("Closest departure time is 12:47pm,arriving at 3:00pm");
			break;
		case 840:
			printf("Closest departure time is 2:00pm,arriving at 4:08pm");
			break;
		case 945:
			printf("Closest departure time is 3:45pm,arriving at 5:55pm");
			break;
		case 1140:
			printf("Closest departure time is 7:00pm,arriving at 9:20pm");
			break;
		case 1305:
			printf("Closest departure time is 9:45pm,arriving at 11:58pm");
			break;
	}
	return 0;
}