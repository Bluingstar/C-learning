#include<stdio.h>
int main(void) {
	double fee = 0, total = 0;
	double bill = 0, avbill = 0;
	for (int i = 0; i < 7; i++)
	{
		printf("Day %d electricity consumption:", i + 1);
		scanf_s("%lf", &fee);
		total = total + fee;
	}
	bill = total * 0.6;
	avbill = total / 7;
	printf("===Eletricity Bill Statistics===\nWeekly total electricity consumption:%lf kWh\nWeekly total electricity bill:%lf RMB\nAverage daily electricity consumption:%lf kWh", total, bill, avbill);
	if (total>40)
	{
		printf("\nWarning:Energy consumption is too high this week!");
	}
	return 0;
}