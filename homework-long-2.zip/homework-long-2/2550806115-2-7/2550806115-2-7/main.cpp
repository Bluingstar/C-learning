#include <stdio.h>
#include <ctype.h>

int main(void) {
    char ch;
    int sum = 0;

    printf("Enter a word: ");
    while ((ch = getchar()) != '\n' && ch != EOF) {
        ch = toupper(ch);  // ͳһת��Ϊ��д��ĸ����
        switch (ch) {
            // 1���飺10��Ԫ���ͳ��ø���
        case 'A': case 'E': case 'I': case 'L': case 'N':
        case 'O': case 'R': case 'S': case 'T': case 'U':
            sum += 1;
            break;
            // 2����
        case 'D': case 'G':
            sum += 2;
            break;
            // 3����
        case 'B': case 'C': case 'M': case 'P':
            sum += 3;
            break;
            // 4����
        case 'F': case 'H': case 'V': case 'W': case 'Y':
            sum += 4;
            break;
            // 5����
        case 'K':
            sum += 5;
            break;
            // 8����
        case 'J': case 'X':
            sum += 8;
            break;
            // 10���飺��ϡȱ��ĸ
        case 'Q': case 'Z':
            sum += 10;
            break;
            // �ǵ÷��ַ��Զ�����
        default:
            break;
        }
    }
    printf("Scrabble value: %d\n", sum);
    return 0;
}
